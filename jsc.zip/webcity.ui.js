/**
Copyright (c) 2009 Tony Finn

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/
$(document).ready(function() {
	// Drag and Drop code (for toolbox, etc.)
	jsc.ui.dragging = false;
	jsc.ui.drag_element = null;
	
	$(".drag-target").mousedown(function() {
		jsc.ui.drag_element =  $(this);
		jsc.ui.dragging = true;
	});
	$("html").mousemove(function(e) {
		if(jsc.ui.dragging) {
			jsc.ui.drag_element.css({"position": "absolute", "top": e.clientY - 1, "left": e.clientX - 1, "z-index": "100"}); // - 1s are due to IE not leaving go otherwise
			$("#overlay").show(); // Overlay stops text beneath being selected. TODO Stop current elements text being selected.
		}
	});
	$(".drag-target").mouseup(function() {
		if(jsc.ui.dragging) {
			jsc.ui.dragging = false;
			jsc.ui.drag_element.css("z-index", "98");
			$("#overlay").hide();
		}
	});
	
	// Code for managing the status bar.
	$("#body table").mouseover(function(e) {
		var coord_array = $(e.target).attr("class").split("-");
		$("#co-ords").html("X:" + coord_array[0] + " Y:" + coord_array[1]);
	});

	// Code for handling selections.
	jsc.data.selection = {startX: -1, startY: -1, endX: -1, endY: -1};
	jsc.ui.select_step = 1;
	$("#body table").click(function(e) {
		var tr = $(e.target).parent('tr');
		var x = $('tr', this).index(tr);
		var y = tr.children('td').index($(e.target));
		
		
		if(jsc.ui.select_step == 1) {
			// Step 1, set starting co-ordinates.
			jsc.data.selection.startX = x;
			jsc.data.selection.startY = y;
			jsc.ui.select_step = 2;
		} else {
			// Step 2. Process selection and display.
			jsc.data.selection.endX = x;
			jsc.data.selection.endY = y;
			
			// Enable multi directional selects
			if(jsc.data.selection.endX < jsc.data.selection.startX) {
				temp = jsc.data.selection.startX;
				jsc.data.selection.startX = jsc.data.selection.endX;
				jsc.data.selection.endX = temp;
			}
			if(jsc.data.selection.endY < jsc.data.selection.startY) {
				temp = jsc.data.selection.startY;
				jsc.data.selection.startY = jsc.data.selection.endY;
				jsc.data.selection.endY = temp;
			}
			jsc.ui.clearSelection();
			jsc.ui.redrawSelection();
			jsc.ui.select_step = 1;
		}
	});
});
jsc.ui = {};
jsc.ui.update = function() {
	$("#cash").html("$" + jsc.data.cash);
	$("#time").html("" + jsc.clock.day + "/" + jsc.clock.month + "/" + jsc.clock.year);
	$("#pop").html(jsc.data.citizens);
	$("#RCI-R").html(jsc.data.resDemand);
	$("#RCI-C").html(jsc.data.comDemand);
	$("#RCI-I").html(jsc.data.indDemand);
}
// Redraws the selection. Uses jsc.data.selection
jsc.ui.redrawSelection = function() {
	for(row = jsc.data.selection.startX; row <= jsc.data.selection.endX; row++) {
		for(col = jsc.data.selection.startY; col <= jsc.data.selection.endY; col++) {
			$("." + row + "-" + col).addClass("selected");
		}
	}
}
// Draws off the selection
jsc.ui.clearSelection = function() {
	$(".selected").removeClass("selected");
	jsc.ui.select_step = 1;
}