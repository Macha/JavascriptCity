$(document).ready(function() {
	for(process in jsc.processes) {
		jsc.processes[process].init();
	}
});
jsc.processes = {};
jsc.processData = {};

jsc.processes.tax = {};
jsc.processes.tax.init = function() { return false; };
jsc.processes.tax.run = function() {
	for(i=0; i < jsc.core.grid_size; i++) {
		for (j=0; j<jsc.core.grid_size; j++) {
			if(
				(jsc.data.cells[i][j].type == "res" || jsc.data.cells[i][j].type == "com" || jsc.data.cells[i][j].type == "ind") &&
				jsc.data.cells[i][j].developed
			) {
				jsc.data.cash++;
			}
		}
	}
}

jsc.processes.develop = {};
jsc.processes.develop.init = function() {
	jsc.processData.develop = {};
	jsc.data.resDemand = 10;
	jsc.data.comDemand = 8;
	jsc.data.indDemand = 5;
}
jsc.processes.develop.run = function() {
	for(i=0; i < jsc.core.grid_size; i++) {
		for (j=0; j<jsc.core.grid_size; j++) {
		
			if(jsc.data.cells[i][j].type == "res") {
				num = jsc.core.getRand();
				if(num < jsc.data.resDemand) {
					jsc.data.cells[i][j].developed = true;
					jsc.data.citizens += 10;
					$("." + i + "-" + j).addClass("developed");
				}
			} else if(jsc.data.cells[i][j].type == "com") {
				num = jsc.core.getRand();
				if(num < jsc.data.comDemand) {
					jsc.data.cells[i][j].developed = true;
					jsc.data.jobs += 3;
					$("." + i + "-" + j).addClass("developed");
				}
			} else if(jsc.data.cells[i][j].type == "ind") {
				num = jsc.core.getRand();
				if(num < jsc.data.indDemand) {
					jsc.data.jobs += 10;
					jsc.data.cells[i][j].developed = true;
					$("." + i + "-" + j).addClass("developed");
				}
			}
		}
	}
}
jsc.processes.jobRatio = {};
jsc.processes.jobRatio.init = function() {
}
jsc.processes.jobRatio.run = function() {
	if(jsc.data.jobs > jsc.data.citizens) {
		jsc.data.resDemand += 2;
		jsc.data.comDemand -= 1;
		jsc.data.indDemand -= 2;
	} else if(jsc.data.citizens > jsc.data.jobs) {
		jsc.data.resDemand -= 2;
		jsc.data.comDemand += 1;
		jsc.data.indDemand += 2;
	}
}