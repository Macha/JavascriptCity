<!DOCTYPE html>
<html>
	<head>
		<title>Web City</title>
		<script type="text/javascript" src="jquery.js"></script>
		<script type="text/javascript" src="webcity.js"></script>
		<script type="text/javascript" src="webcity.processes.js"></script>
		<script type="text/javascript" src="webcity.tools.js"></script>
		<script type="text/javascript" src="webcity.ui.js"></script>
		
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<div id="menu">
			Welcome to Javascript City, the web based city management game.
		</div>
		<div id="body">
			<?php require("grid.php"); ?>
		</div>
			<div id="status-bar">
				<span id="cash">$10,000</span> | 
				<span id="co-ords">X:0 Y:0</span> | 
				<span id="time">1/1/1900</span> | 
				Population: <span id="pop">0</span> |
				RCI:
				R:<span id="RCI-R"></span> C:<span id="RCI-C"></span> I:<span id="RCI-I"></span>
		</div>
		<div id="toolbox" class="drag-target">
			<h2>Tools</h2>
			<table id="tools">
				<tr><td id="res"><img src="images/res.png" alt="Zone Residential" width="30" height="30" /></td><td id="com"><img src="images/com.png" alt="Zone Commercial" width="30" height="30" /></td></tr>
				<tr><td id="ind"><img src="images/ind.png" alt="Zone Industrial" width="30" height="30" /></td><td id="road"><img src="images/road.png" alt="Lay Road" width="30" height="30" /></td></tr>
			</table>
		</div>
		<div id="load-div">
		</div>
		<div id="overlay">
		</div>
	</body>
</html>