$(document).ready(function() {
	for(tool in jsc.tools) {
		jsc.tools[tool].init();
	}
});
// Used to store the tools functions themselves.
jsc.tools = {};
// Used to store the data used by tools. Each tool should have a sub property assigned to it.
jsc.toolData = {};

jsc.tools.res = {};
jsc.tools.res.run = function() {
	for(row = jsc.data.selection.startX; row <= jsc.data.selection.endX; row++) {
		if(jsc.data.cash < jsc.toolData.res.cost) {
			break;
		}
		for(col = jsc.data.selection.startY; col <= jsc.data.selection.endY; col++) {
			if(jsc.data.cash < jsc.toolData.res.cost) {
				break;
			}
			if(jsc.data.cells[row][col].type != null) {
				jsc.tools[jsc.data.cells[row][col].type].remove();
			}
			jsc.data.cells[row][col].type = "res";
			jsc.data.cash -= jsc.toolData.res.cost;
			$("." + row + "-" + col).addClass("res");
			jsc.ui.clearSelection();
		}
	}
}
jsc.tools.res.init = function() {
	jsc.toolData.res = {};
	jsc.toolData.res.cost = 15;
}
jsc.tools.res.remove = function(x, y) {
	jsc.data.cells[x][y].type = null;
	jsc.data.cells[x][y].developed = false;
	$("." + x + "-" + y).removeClass("res");
	$("." + x + "-" + y).removeClass("developed");
}

jsc.tools.ind = {};
jsc.tools.ind.run = function() {
	for(row = jsc.data.selection.startX; row <= jsc.data.selection.endX; row++) {
		if(jsc.data.cash < jsc.toolData.ind.cost) {
			break;
		}
		for(col = jsc.data.selection.startY; col <= jsc.data.selection.endY; col++) {
			if(jsc.data.cash < jsc.toolData.ind.cost) {
				break;
			}
			if(jsc.data.cells[row][col].type != null) {
				jsc.tools[jsc.data.cells[row][col].type].remove();
			}
			jsc.data.cells[row][col].type = "ind";
			jsc.data.cash -= jsc.toolData.ind.cost;
			$("." + row + "-" + col).addClass("ind");
			jsc.ui.clearSelection();
		}
	}
}
jsc.tools.ind.init = function() {
	jsc.toolData.ind = {};
	jsc.toolData.ind.cost = 20;
}
jsc.tools.ind.remove = function(x, y) {
	jsc.data.cells[x][y].type = null;
	jsc.data.cells[x][y].developed = false;
	$("." + x + "-" + y).removeClass("ind");
	$("." + x + "-" + y).removeClass("developed");
}
jsc.tools.com = {};
jsc.tools.com.run = function() {
	for(row = jsc.data.selection.startX; row <= jsc.data.selection.endX; row++) {
		if(jsc.data.cash < jsc.toolData.com.cost) {
			break;
		}
		for(col = jsc.data.selection.startY; col <= jsc.data.selection.endY; col++) {
			if(jsc.data.cash < jsc.toolData.com.cost) {
				break;
			}
			if(jsc.data.cells[row][col].type != null) {
				jsc.tools[jsc.data.cells[row][col].type].remove();
			}
			jsc.data.cells[row][col].type = "com";
			jsc.data.cash -= jsc.toolData.com.cost;
			$("." + row + "-" + col).addClass("com");
			jsc.ui.clearSelection();
		}
	}
}
jsc.tools.com.init = function() {
	jsc.toolData.com = {};
	jsc.toolData.com.cost = 20;
}
jsc.tools.com.remove = function(x, y) {
	jsc.data.cells[x][y].type = null;
	jsc.data.cells[x][y].developed = false;
	$("." + x + "-" + y).removeClass("com");
	$("." + x + "-" + y).removeClass("developed");
}

jsc.tools.road = {};
jsc.tools.road.init = function() {
	jsc.toolData.road = {};
	jsc.toolData.road.cost = 3;
}
jsc.tools.road.run = function() {
	for(row = jsc.data.selection.startX; row <= jsc.data.selection.endX; row++) {
		if(jsc.data.cash < jsc.toolData.road.cost) {
			break;
		}
		for(col = jsc.data.selection.startY; col <= jsc.data.selection.endY; col++) {
			if(jsc.data.cash < jsc.toolData.road.cost) {
				break;
			}
			if(jsc.data.cells[row][col].type != null) {
				jsc.tools[jsc.data.cells[row][col].type].remove();
			}
			jsc.data.cells[row][col].type = "road";
			jsc.data.cash -= jsc.toolData.road.cost;
			$("." + row + "-" + col).addClass("road");
			jsc.ui.clearSelection();
		}
	}
}
jsc.tools.road.remove = function(x, y) {
	jsc.data.cells[x][y].type = null;
	jsc.data.cells[x][y].developed = false;
	$("." + x + "-" + y).removeClass("road");
}