$(document).ready(function() {
 	jsc.init();
	$("#tools td").click(function(e) {
		jsc.tools[$(this).attr("id")].run(); // Calls the function in jsc.tools based on the tools id in the HTML source.
	});
	
	setTimeout("jsc.update()", jsc.core.day_length);
});
jsc = {}; // Initialise Core jsc object
// Initialise JSC subobjects
// Core settings. Set at startup. Should not be modified during run.
jsc.core = {};
// The clock. Used to store timekeeping data.
jsc.clock = {};
// Updateable data. This is used to keep track of data in use. e.g. 
jsc.data = {};


jsc.clock.day = 1;
jsc.clock.month = 1;
jsc.clock.year = 1900;
jsc.clock.daysInMonth = [31,28,31,30,31,30,31,31,30,31,30,31];
jsc.init = function() {
	
	jsc.core.day_length = 2500;
	jsc.core.grid_size = 200;
	
	jsc.data.cash = 10000;
	jsc.data.citizens = 0;
	jsc.data.jobs = 0;
	
	// Initialise cells to null
	jsc.data.cells = [];
	for(x = 0; x < jsc.core.grid_size; x++) {
		jsc.data.cells[x] = [];
		for(y = 0; y < jsc.core.grid_size; y++) {
			jsc.data.cells[x][y] = {type: null, developed: false, powered: false, watered: false, hasTransport: false};
		}
	}
}
// Core updating function. Runs different update functions in a loop.
jsc.update = function() {
	jsc.clock.update();
	if(jsc.clock.day == 1) { // First week run budget
		jsc.core.doBudget();
	} else if (jsc.clock.day == 8 || jsc.clock.day == 15 || jsc.clock.day == 22) {
		for(process in jsc.processes) {
			jsc.processes[process].run();
		}
	}
	jsc.ui.update();
	setTimeout(jsc.update, jsc.core.day_length);
};
jsc.core.doBudget = function() {
	return false; // TODO implement
}
jsc.core.getRand = function() {
	return Math.floor(Math.random() * 100);
}
// Updates clock
jsc.clock.update = function() {
	jsc.clock.day++;
	if(jsc.clock.day > jsc.clock.daysInMonth[jsc.clock.month - 1]) {
		jsc.clock.day = 1;
		jsc.clock.month++;
		if(jsc.clock.month >= 12) { 
			jsc.clock.month = 1;
			jsc.clock.year++;
		}
	}
}